﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;

namespace TP_Final_BD_MVC_Session5
{
    public class Constants
    {
        //public const string ConnectionString = "Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\Dominic\\Desktop\\Session5-TP-MVC-Chourot\\TP-Final-BD-MVC-Session5\\App_Data\\MainDB.mdf;Integrated Security=True;Connect Timeout=10";
        //public const string ConnectionString = "Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\201356743\\Desktop\\Session5-TP-MVC-Chourot\\TP-Final-BD-MVC-Session5\\App_Data\\MainDB.mdf;Integrated Security=True;Connect Timeout=10";
        public static string ConnectionString;// = "Data Source=(LocalDB)\\v11.0;AttachDbFilename='D:\\My Documents\\Projects\\Session5-TP-MVC-Chourot\\TP-Final-BD-MVC-Session5\\App_Data\\MainDB.mdf';Integrated Security=True;Connect Timeout=10";
    }

}